print("train model")
